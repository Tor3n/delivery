

# Error


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**code** | **Integer** | Код ошибки |  |
|**message** | **String** | Текст ошибки |  |



