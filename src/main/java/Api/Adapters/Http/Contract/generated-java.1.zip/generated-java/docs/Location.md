

# Location


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**x** | **Integer** | X |  |
|**y** | **Integer** | Y |  |



