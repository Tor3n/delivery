

# Order


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **UUID** | Идентификатор |  |
|**location** | [**Location**](Location.md) |  |  |



