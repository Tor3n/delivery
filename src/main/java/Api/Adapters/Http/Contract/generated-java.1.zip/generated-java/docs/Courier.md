

# Courier


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **UUID** | Идентификатор |  |
|**name** | **String** | Имя |  |
|**location** | [**Location**](Location.md) |  |  |



