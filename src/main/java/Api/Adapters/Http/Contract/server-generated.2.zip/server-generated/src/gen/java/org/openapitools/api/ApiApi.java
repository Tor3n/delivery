package org.openapitools.api;

import org.openapitools.api.ApiApiService;
import org.openapitools.api.factories.ApiApiServiceFactory;

import io.swagger.annotations.ApiParam;
import io.swagger.jaxrs.*;

import org.openapitools.model.Courier;
import org.openapitools.model.Error;
import org.openapitools.model.Order;

import java.util.Map;
import java.util.List;
import org.openapitools.api.NotFoundException;

import java.io.InputStream;

import org.glassfish.jersey.media.multipart.FormDataParam;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;

import javax.servlet.ServletConfig;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.*;
import javax.validation.constraints.*;
import javax.validation.Valid;

@Path("/api/v1")


@io.swagger.annotations.Api(description = "the api API")
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaJerseyServerCodegen", date = "2025-04-15T00:36:13.226579284+03:00[Europe/Moscow]", comments = "Generator version: 7.12.0")
public class ApiApi  {
   private final ApiApiService delegate;

   public ApiApi(@Context ServletConfig servletContext) {
      ApiApiService delegate = null;

      if (servletContext != null) {
         String implClass = servletContext.getInitParameter("ApiApi.implementation");
         if (implClass != null && !"".equals(implClass.trim())) {
            try {
               delegate = (ApiApiService) Class.forName(implClass).getDeclaredConstructor().newInstance();
            } catch (Exception e) {
               throw new RuntimeException(e);
            }
         }
      }

      if (delegate == null) {
         delegate = ApiApiServiceFactory.getApiApi();
      }

      this.delegate = delegate;
   }

    @javax.ws.rs.POST
    @Path("/orders")
    
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Создать заказ", notes = "Позволяет создать заказ с целью тестирования", response = Void.class, tags={  })
    @io.swagger.annotations.ApiResponses(value = {
        @io.swagger.annotations.ApiResponse(code = 201, message = "Успешный ответ", response = Void.class),
        @io.swagger.annotations.ApiResponse(code = 200, message = "Ошибка", response = Error.class)
    })
    public Response createOrder(@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.createOrder(securityContext);
    }
    @javax.ws.rs.GET
    @Path("/couriers")
    
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Получить всех курьеров", notes = "Позволяет получить всех курьеров", response = Courier.class, responseContainer = "List", tags={  })
    @io.swagger.annotations.ApiResponses(value = {
        @io.swagger.annotations.ApiResponse(code = 200, message = "Успешный ответ", response = Courier.class, responseContainer = "List"),
        @io.swagger.annotations.ApiResponse(code = 200, message = "Ошибка", response = Error.class)
    })
    public Response getCouriers(@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.getCouriers(securityContext);
    }
    @javax.ws.rs.GET
    @Path("/orders/active")
    
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Получить все незавершенные заказы", notes = "Позволяет получить все незавершенные", response = Order.class, responseContainer = "List", tags={  })
    @io.swagger.annotations.ApiResponses(value = {
        @io.swagger.annotations.ApiResponse(code = 200, message = "Успешный ответ", response = Order.class, responseContainer = "List"),
        @io.swagger.annotations.ApiResponse(code = 200, message = "Ошибка", response = Error.class)
    })
    public Response getOrders(@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.getOrders(securityContext);
    }
}
